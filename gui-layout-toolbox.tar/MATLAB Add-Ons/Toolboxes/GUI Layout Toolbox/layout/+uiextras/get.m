function varargout = get( ~, ~ ) %#ok<STOUT>
%uiextras.get  Retrieve a default property value from a parent object
%
%  This functionality has been removed.

%  Copyright 2009-2020 The MathWorks, Inc.

% Check inputs
narginchk( 2, 2 )

% Error
error( 'uiextras:Deprecated', 'uiextras.get has been removed.' )

end % uiextras.get