function set( ~, ~, ~ )
%uiextras.set  Store a default property value in a parent object
%
%  This functionality has been removed.

%  Copyright 2009-2020 The MathWorks, Inc.

% Check inputs
narginchk( 3, 3 )

% Warn
warning( 'uiextras:Deprecated', 'uiextras.set has been removed.' )

end % uiextras.set